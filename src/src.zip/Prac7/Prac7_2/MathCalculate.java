package Prac7.Prac7_2;

public interface MathCalculate {

    double toSecPower(double x);
    double findModComplex(double a, double b);

    double Pi = Math.PI;

}
