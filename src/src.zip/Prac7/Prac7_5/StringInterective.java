package Prac7.Prac7_5;

public interface StringInterective {
    int countSymbols(String s);
    String newStringFromExactPositions(String s);
    String invertion(String s);
}

