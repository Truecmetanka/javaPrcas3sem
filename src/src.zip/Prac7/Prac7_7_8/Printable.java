package Prac7.Prac7_7_8;

public interface Printable {
    void print();
}
