package Prac6.Prac6_8;

public interface Printable {
    void print();
}
