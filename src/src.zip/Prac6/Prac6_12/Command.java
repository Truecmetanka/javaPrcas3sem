package Prac6.Prac6_12;

public interface Command // интерфейс одной команды
{
    void execute(String str, int...args);
    void undo();
}
