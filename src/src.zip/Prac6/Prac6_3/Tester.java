package Prac6.Prac6_3;

public class Tester {
    public static void main(String[] args) {
        Cars car = new Cars("Lada");
        System.out.println(car.getName());
        Animals animal = new Animals("Tiger");
        System.out.println(animal.getName());
    }
}
