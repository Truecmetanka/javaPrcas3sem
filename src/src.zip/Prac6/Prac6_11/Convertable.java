package Prac6.Prac6_11;

public interface Convertable {
    double[] convert();
}
