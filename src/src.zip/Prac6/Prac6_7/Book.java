package Prac6.Prac6_7;

import Prac6.Prac6_4.Priceable;

public class Book implements Printable {

    private String name;

    public Book(String name) {
        this.name = name;
    }

    @Override
    public void print() {
        System.out.println(name);
    }
}
