package Prac6.Prac6_7;

public interface Printable {
    void print();
}
