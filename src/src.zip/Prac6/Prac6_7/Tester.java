package Prac6.Prac6_7;

import Prac6.Prac6_8.Shop;

public class Tester {
    public static void main(String[] args) {
        Shop b = new Shop("Flowers");
        b.print();
    }
}
