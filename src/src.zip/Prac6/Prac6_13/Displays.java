package Prac6.Prac6_13;

public interface Displays
{
    void display();
}
