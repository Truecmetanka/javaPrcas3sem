package Prac6.Prac6_13;

public interface Observer
{
    void update(StringBuilder str);
}
