package Prac6.Prac6_6;

public interface Printable {
    void print();
}
