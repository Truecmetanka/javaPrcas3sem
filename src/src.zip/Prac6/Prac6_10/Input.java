package Prac6.Prac6_10;

public interface Input {
    Computer input();
}
