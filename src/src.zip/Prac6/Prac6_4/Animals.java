package Prac6.Prac6_4;

public class Animals implements Priceable {

    private int price;

    public Animals(int price) {
        this.price = price;
    }

    @Override
    public int getPrice() {
        return price;
    }
}
