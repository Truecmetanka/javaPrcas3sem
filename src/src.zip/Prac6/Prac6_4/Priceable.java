package Prac6.Prac6_4;

public interface Priceable {
    int getPrice();
}
