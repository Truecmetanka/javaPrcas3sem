package lab29_30.extensions;

public class OrderAlreadyAddedException extends Exception {
}
