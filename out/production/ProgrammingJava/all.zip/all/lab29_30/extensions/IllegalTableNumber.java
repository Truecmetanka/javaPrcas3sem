package lab29_30.extensions;

public class IllegalTableNumber extends RuntimeException {
}
