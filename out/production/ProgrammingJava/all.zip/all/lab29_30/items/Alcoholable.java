package lab29_30.items;

public interface Alcoholable {
    boolean isAlcoholicDrink();
    double getAlcoholVol();
}
