package lab29_30.items;

public class Dish extends MenuItem {

    public Dish(int cost, String name, String description) {
        super(cost, name, description);
    }
}
