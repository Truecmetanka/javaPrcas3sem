package lab11;

import java.util.Date;

public class Task1 {
    public static void main(String[] args) {
        System.out.println("Матросов 17.11.2022 17:00");
        System.out.println(new Date());
    }
}
/* Написать программу, выводящую фамилию разработчика, дату и время
    получения задания, а также дату и время сдачи задания. Для получения
        последней даты и времени использовать класс Date из пакета java.util.**/
