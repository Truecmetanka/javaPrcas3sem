package lab06.Prac6_9;

public interface Printable {
    void print();
}
