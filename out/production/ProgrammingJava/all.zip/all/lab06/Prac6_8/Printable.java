package lab06.Prac6_8;

public interface Printable {
    void print();
}
