package lab06.Prac6_8;

public class Tester {
    public static void main(String[] args) {
        Shop b = new Shop("Hello");
        b.print();
    }
}
