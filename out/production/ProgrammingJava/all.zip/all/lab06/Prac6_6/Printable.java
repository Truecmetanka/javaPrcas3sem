package lab06.Prac6_6;

public interface Printable {
    void print();
}
