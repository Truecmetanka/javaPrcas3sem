package lab06.Prac6_3;

public interface Nameable {
    String getName();
}
