package lab06.Prac6_3;

public class Animals implements Nameable{


    public Animals(String name) {
        this.name = name;
    }

    private String name;

    @Override
    public String getName() {
        return name;
    }
}
