package lab06.Prac6_7;

public interface Printable {
    void print();
}
