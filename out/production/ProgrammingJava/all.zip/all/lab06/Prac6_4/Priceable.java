package lab06.Prac6_4;

public interface Priceable {
    int getPrice();
}
