package lab06.Prac6_10;

public class Processor {
    private String name;

    public Processor(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
