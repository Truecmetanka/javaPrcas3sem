package lab06.Prac6_10;

public interface Input {
    Computer input();
}
