package lab06.Prac6_10;

public class Memory {
    private String name;

    public Memory(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
