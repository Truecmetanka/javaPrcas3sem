package lab06.Prac6_10;

public class Monitor  {
    private String name;

    public Monitor(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

}
