package lab02.task03;

public class Circle {
    private Point point;

    public Circle(Point point) {
        this.point = point;
    }
}
