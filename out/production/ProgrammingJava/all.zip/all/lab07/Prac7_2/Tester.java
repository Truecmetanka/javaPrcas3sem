package lab07.Prac7_2;

public class Tester {
    public static void main(String[] args) {
        MathFunc func = new MathFunc();
        System.out.println(func.findLengthOfCircle(10));
        System.out.println(func.findModComplex(12, 4));
        System.out.println(func.toSecPower(18));
    }
}
