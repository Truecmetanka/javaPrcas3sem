package lab07.Prac7_5;

public interface StringInterective {
    int countSymbols(String s);
    String newStringFromExactPositions(String s);
    String invertion(String s);
}

