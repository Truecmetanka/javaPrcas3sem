package lab07.Prac7_5;

public class Tester {
    public static void main(String[] args) {
        ProcessSrting s = new ProcessSrting();
        System.out.println(s.countSymbols("Hello"));
        System.out.println(s.newStringFromExactPositions("Hello"));
        System.out.println(s.invertion("Hello"));
    }
}
