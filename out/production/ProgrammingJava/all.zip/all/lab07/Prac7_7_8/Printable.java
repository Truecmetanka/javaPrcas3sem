package lab07.Prac7_7_8;

public interface Printable {
    void print();
}
