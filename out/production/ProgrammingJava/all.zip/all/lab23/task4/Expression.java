package lab23.task4;

public interface Expression {
    int evaluate(int ...vars);
}
