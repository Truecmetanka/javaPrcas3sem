package lab23.task3;

public interface Expression {
    int evaluate(int var);
}
